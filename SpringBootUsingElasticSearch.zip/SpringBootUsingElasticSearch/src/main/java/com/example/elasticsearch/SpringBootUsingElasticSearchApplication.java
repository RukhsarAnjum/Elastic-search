package com.example.elasticsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUsingElasticSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUsingElasticSearchApplication.class, args);
	}

}
