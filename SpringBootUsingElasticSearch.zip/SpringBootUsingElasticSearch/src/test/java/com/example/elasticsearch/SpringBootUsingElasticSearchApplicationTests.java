package com.example.elasticsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUsingElasticSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
